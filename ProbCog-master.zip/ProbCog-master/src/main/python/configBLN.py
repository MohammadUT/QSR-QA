

from configGUI import *

queryToolSettingsFilename = "blnquery.config.dat"

# path where the ACE 2.0 compile and evalute tools can be found
# must be set if you want to use the "ACE" inference method
acePath = "/usr/wiss/jain/apps/ace2"